package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.controller.DictController;

@EnableJpaRepositories("com.example.repo")
@EntityScan("com.example.model")
@ComponentScan(basePackageClasses = DictController.class)
@SpringBootApplication
public class Dictionary3Application {

	public static void main(String[] args) {
		SpringApplication.run(Dictionary3Application.class, args);
	}

}
