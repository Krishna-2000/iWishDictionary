package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="dict")
public class Dictionary {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String keyword;
	private String descr;
	private int img;
	
	
	public Dictionary() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Dictionary(int id, String keyword, String descr, int img) {
		super();
		this.id = id;
		this.keyword = keyword;
		this.descr = descr;
		this.img = img;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getKeyword() {
		return keyword;
	}


	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}


	public String getDescr() {
		return descr;
	}


	public void setDescr(String descr) {
		this.descr = descr;
	}


	public int getImg() {
		return img;
	}


	public void setImg(int img) {
		this.img = img;
	}


	@Override
	public String toString() {
		return "Dictionary [id=" + id + ", keyword=" + keyword + ", descr=" + descr + ", img=" + img + "]";
	}
	
	
}
