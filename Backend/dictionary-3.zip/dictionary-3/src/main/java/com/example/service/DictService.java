package com.example.service;

import java.util.*;

import org.springframework.stereotype.Component;

import com.example.model.Dictionary;

@Component
public interface DictService {
	Dictionary addWord(Dictionary d);
	int updateWord(Dictionary d);
	List<Dictionary> getAll();
	int delWord(String keyword);
	Dictionary search(String keyword);
}
