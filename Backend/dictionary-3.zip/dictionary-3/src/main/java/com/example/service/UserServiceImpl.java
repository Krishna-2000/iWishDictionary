package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.User;
import com.example.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserRepo repo;
	
	@Override
	public User addUser(User e) {
		return repo.save(e);
	}

	@Override
	public User loginCheck(String username, String password) {
		List<User> users = repo.findAll();
		for(int i=0;i<users.size();i++) {
			System.out.println(users.get(i));
			if((users.get(i).getUsername().equals(username)) && (users.get(i).getPassword().equals(password))) {
				return users.get(i);
			}
		}
		return null;
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = repo.findAll();
		return users;
	}
	
}
