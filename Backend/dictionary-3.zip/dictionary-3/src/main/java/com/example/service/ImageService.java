package com.example.service;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.model.Image;
import com.example.repo.ImageRepo;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;


@Service
public class ImageService implements ImageServiceInterface {

	@Autowired
	ImageRepo repo;
	
    public final String storageDirectoryPath = System.getProperty("user.dir")+"/upload";
    
    public ResponseEntity uploadToLocalFileSystem(MultipartFile file) {
    
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

        Path storageDirectory = Paths.get(storageDirectoryPath);
        if(!Files.exists(storageDirectory)){ 
            try {
                Files.createDirectories(storageDirectory); 
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        Path destination = Paths.get(storageDirectory.toString() + "\\" + fileName);
        String keyword = fileName.substring(0,fileName.length()-1);
        String url = destination.toString();
        System.out.println(url);
        saveImage(keyword,url);

        try {
            Files.copy(file.getInputStream(), destination, StandardCopyOption.REPLACE_EXISTING);// we are Copying all bytes from an input stream to a file

        } catch (IOException e) {
            e.printStackTrace();
        }
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("api/images/getImage/")
                .path(fileName)
                .toUriString();
   
        return ResponseEntity.ok(fileDownloadUri);
    }

    public  byte[] getImageWithMediaType(String imageName) throws IOException {
        Path destination = Paths.get(storageDirectoryPath+"\\"+imageName);// retrieve the image by its name

        return IOUtils.toByteArray(destination.toUri());
    }
    
	

	@Override
	public void saveImage(String keyword, String url) {
		// TODO Auto-generated method stub
		Image im=new Image(keyword,url);
		repo.save(im);
	}

	@Override
	public int getNumberOfImages(String keyword) {
		int count=0;
		List<Image> im = repo.findAll();
		for(int i=0;i<im.size();i++) {
			if(im.get(i).getKeyword().equals(keyword)) {
				count++;
			}
		}
		System.out.println(count);
		return count;
	}

	

}