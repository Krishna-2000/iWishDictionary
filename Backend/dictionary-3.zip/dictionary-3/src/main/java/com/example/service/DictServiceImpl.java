package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Dictionary;
import com.example.repo.DictRepo;

@Service
public class DictServiceImpl implements DictService{
	@Autowired
	DictRepo repo;

	@Override
	public Dictionary addWord(Dictionary d) {
		return repo.save(d);
	}

	@Override
	public int updateWord(Dictionary d) {
		Dictionary wrd = search(d.getKeyword());
		repo.deleteById(wrd.getId());
		repo.save(d);
		return 1;
	}

	@Override
	public List<Dictionary> getAll() {
		List<Dictionary> dict = repo.findAll();
		return dict;
	}

	@Override
	public int delWord(String keyword) {
		Dictionary d = search(keyword);
		repo.deleteById(d.getId());
		return 1;
	}

	@Override
	public Dictionary search(String keyword) {
		List<Dictionary> dictionary = repo.findAll();

		for(int i=0;i<dictionary.size();i++) {
			if(dictionary.get(i).getKeyword().equals(keyword)) {
				return dictionary.get(i);
			}
		}
		return null;
	}
	
}
