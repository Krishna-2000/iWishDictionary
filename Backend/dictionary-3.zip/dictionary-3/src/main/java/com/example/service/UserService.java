package com.example.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.model.User;

@Component
public interface UserService {

	User addUser(User e);
	User loginCheck(String username,String password);
	List<User> getAllUsers();
}
 