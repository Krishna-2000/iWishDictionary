package com.example.controller;
import java.io.IOException;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.model.Dictionary;
import com.example.model.User;
import com.example.service.DictService;
import com.example.service.ImageService;
import com.example.service.UserService;

@ComponentScan("com.example.service")
@CrossOrigin(origins="http://localhost:3000")
@RestController
public class DictController {
	
	public static String uploadDirectory=System.getProperty("user.dir")+"/upload";
	
	@Autowired
	DictService service;
	@Autowired
	UserService userservice;
	
	@GetMapping("/hello")
	public String hello() {
		return "hello";
	}
	@GetMapping("/getList")
	public List<Dictionary> getAll(){
		return service.getAll();
	}
	@GetMapping("/getUsers")
	public List<User> getUsers(){
		return userservice.getAllUsers();
	}
	@PostMapping("/create")
	public Dictionary addWord(@RequestBody Dictionary d) {
		return service.addWord(d);
	}
	@GetMapping(value="/search/{keyword}")
	public Dictionary getDict(@PathVariable String keyword) {
		return service.search(keyword);
	}
	@DeleteMapping("/delete/{keyword}")
	public int delDict(@PathVariable String keyword) {
		return service.delWord(keyword);
	}
	@PostMapping("/update")
	public void updateDict(@RequestBody Dictionary d) {
		 service.updateWord(d);
	}
	@PostMapping("/saveUser")
	public User saveUser(@RequestBody User e) {
		return userservice.addUser(e);
	}
	@GetMapping("/validate")
	public User validate(@RequestParam String username,@RequestParam String password) {
		System.out.println(username+" "+password);
		return userservice.loginCheck(username, password);
	}
	
	
	@Autowired
    public ImageService imageService;
	
	@GetMapping(value="/getNum/{keyword}")
	public int getKeywordTotal(@PathVariable String keyword) {
		System.out.println(keyword);
		return imageService.getNumberOfImages(keyword);
	}
	
    @PostMapping(value ="/upload")
    public void uploadImage(@RequestParam MultipartFile[] file){
    	for(int i=0;i<file.length;i++) {
    		this.imageService.uploadToLocalFileSystem(file[i]);
    	}
        
    }
    
    @GetMapping(
            value = "getImage/{imageName:.+}",
            produces = {MediaType.IMAGE_JPEG_VALUE,MediaType.IMAGE_GIF_VALUE,MediaType.IMAGE_PNG_VALUE}
    )
    public @ResponseBody byte[] getImageWithMediaType(@PathVariable(name = "imageName") String fileName) throws IOException {
        return this.imageService.getImageWithMediaType(fileName);
    }
	
	


	
}