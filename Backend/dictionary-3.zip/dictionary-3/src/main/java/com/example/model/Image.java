package com.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="imagestore")
public class Image {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String keyword;
	private String url;
	public Image() {
		// TODO Auto-generated constructor stub
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Image( String keyword, String url) {
		super();
		this.keyword = keyword;
		this.url = url;
	}
	@Override
	public String toString() {
		return "Image [id=" + id + ", keyword=" + keyword + ", url=" + url + "]";
	}
	
	
}
