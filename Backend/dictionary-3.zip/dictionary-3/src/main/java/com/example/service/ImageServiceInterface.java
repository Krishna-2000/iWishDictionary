package com.example.service;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.example.model.Image;

@Component
public interface ImageServiceInterface {
	public ResponseEntity uploadToLocalFileSystem(MultipartFile file);
	public  byte[] getImageWithMediaType(String imageName) throws IOException;
	public void saveImage(String keyword,String url);
	public int getNumberOfImages(String keyword);
}
