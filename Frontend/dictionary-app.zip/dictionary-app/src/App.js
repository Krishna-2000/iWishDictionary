import './App.css';
import Login from './components/Login';
import {  BrowserRouter as Router,Route,Switch } from 'react-router-dom';
import Home from './components/Home';
import Registration from './components/Registration';
import HomeAdmin from './components/HomeAdmin';
import ViewAll from './components/ViewAll';
import AddWord from './components/AddWord';
import Search from './components/Search';
import Delete from './components/Delete';
import Find from './components/Find';
import Keyword from './components/Keyword';
import Update from "./components/Update"
import GetUsers from './components/GetUsers';
import AdminSearch from './components/AdminSearch';
import AdminViewAll from './components/AdminView';
import KeywordAdmin from './components/KeywordAdmin';
import AddAdmin from './components/AddAdmin';

function App() {
  return (
    <div className="App">
        <div className="container">
          <Router>
            <Switch>
              <Route path="/login" component={Login}></Route>
              <Route path="/home" component={Home}></Route>
              <Route path="/reg" component={Registration}></Route>
              <Route path="/homeadmin" component={HomeAdmin}></Route>
              <Route path="/view" component={ViewAll}></Route>
              <Route path="/add" component={AddWord}></Route>
              <Route path="/search" component={Search}></Route>
              <Route path="/find" component={Find}></Route>
              <Route path="/delete" component={Delete}></Route>
              <Route path="/keyword" component={Keyword}></Route>
              <Route path="/keywordadmin" component={KeywordAdmin}></Route>
              <Route path="/update" component={Update}></Route>
              <Route path="/users" component={GetUsers}></Route>
              <Route path="/searchadmin" component={AdminSearch}></Route>
              <Route path="/adminview" component={AdminViewAll}></Route>
              <Route path="/addadmin" component={AddAdmin}></Route>
            </Switch>
          </Router>
          {/* <div className="container" id="add-page">

          </div> */}
        </div>
    </div>
  );
}

export default App;
