import axios from "axios";

const API_BASE_DELETE="http://localhost:8086/delete/";
const API_BASE_UPLOAD="http://localhost:8086/upload";
const API_BASE_GETIMAGE="http://localhost:8086/getImage/";
const API_IMAGE_TOTAL="http://localhost:8086/getNum/";
const API_BASE_ADD_WORD="http://localhost:8086/create";
const API_BASE_ADD_UPDATE="http://localhost:8086/update";
const API_GET_ALL_USERS="http://localhost:8086/getUsers";

class AdminService{
    deleteWord(keyword){
        return axios.delete(API_BASE_DELETE+keyword);
    }
    upload(data) {
        return axios.post(API_BASE_UPLOAD, data);
    }
    getImage(keyword){
        return axios.get(API_BASE_GETIMAGE+keyword);
    }
    getNumOfImag(keyword){
        return axios.get(API_IMAGE_TOTAL+keyword);
    }
    addWord(data){
        return axios.post(API_BASE_ADD_WORD,data);
    }
    updateWord(data){
        return axios.post(API_BASE_ADD_UPDATE,data);
    }
    getUsers(){
        return axios.get(API_GET_ALL_USERS);
    }
}
export default new AdminService();