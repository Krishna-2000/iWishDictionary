import axios from "axios";

const API_BASE_GETLIST="http://localhost:8086/getList";
const API_BASE_SEARCH="http://localhost:8086/search/";

class CommonService{
    getList(){
        return axios.get(API_BASE_GETLIST);
    }
    searchList(word){
        return axios.get(API_BASE_SEARCH+word);
    }
}
export default new CommonService();