import axios from "axios";

const API_BASE_LOGIN="http://localhost:8086/validate?";

class LoginService{
    loginValidate(uname,pass){
        return axios.get(API_BASE_LOGIN+"username="+uname+"&password="+pass);
    }
}
export default new LoginService();