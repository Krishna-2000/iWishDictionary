import axios from "axios";

const API_BASE_REGISTER="http://localhost:8086/saveUser";

class RegService{
    register(data){
        return axios.post(API_BASE_REGISTER,data);
    }
}
export default new RegService();