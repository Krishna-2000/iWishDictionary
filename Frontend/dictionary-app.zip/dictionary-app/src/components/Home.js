import React, { Component, Fragment } from 'react';
import AliceCarousel from 'react-alice-carousel';
import "react-alice-carousel/lib/alice-carousel.css";

class Home extends Component {
    constructor(props){
      super(props);
      this.state={
        images:['frnt3.jpg','frnt2.jpg','frnt1.webp','bg.jpeg'],
        wish:"wish.jpg"
      }
      console.log(this.state.images);
    }
    render() {
        return (
            <div className="container" id="add-page">
                <div class="sidenav2">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                   <a></a>
                  <a></a>
                <a href="/search"><b>SEARCH</b></a>
                <a href="/view"><b>GLOSSARY</b></a>
                </div>
                <div >
                    <div class="card"  style={{width: "65rem",height:"33rem"}}>
                    <br></br>
                <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title" style={{fontFamily:"fantasy"}}><b>&emsp;iWish Softwares</b></h2>
                    <div id="logout"><a href="/login">Logout</a></div>
                    </div></div><br></br>
                    <small style={{color:"red"}} id="err"></small>
                <div>
                <div style={{fontFamily:"cursive"}}>
                  Welcome to iWish Software...<br></br>
               <div> i<b>Wish</b> wish you a happy Learning Experience! </div>  
                </div>
               <div className="card-body" id="homepage" style={{paddingLeft:"100px"}}>
                <AliceCarousel autoPlay autoPlayInterval="3000" infinite="true" disableDotsControls="true">
                                {
                                this.state.images.map(
                                    image => 
                                    <img src={image} className="sliderimg" style={{height:"300px",width:"700px"}} alt={image}  />
                                )
                            }
                             </AliceCarousel>
                             </div>
                </div><br></br>

                              
                    
                    </div>
                </div>
                </div>
        
        );
    }
}

export default Home;