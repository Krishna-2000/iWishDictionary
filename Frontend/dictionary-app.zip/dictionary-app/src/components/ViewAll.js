import React, { Component } from 'react';
import CommonService from '../service/CommonService';
import { Modal,Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import AdminService from '../service/AdminService';

class ViewAll extends Component {
    constructor(props){
        super(props);
        this.state={
            words:[],
            keywords:[],
            isOpen:false,
            
        }
    }
    openModal = () => 
    this.setState({ 
        isOpen: true 
    });
    closeModal = () =>{ 
        this.setState({ isOpen: false });

    }
    componentDidMount(){
       
        CommonService.getList()
        .then((res)=>{
            this.setState({
                words:res.data
            })
            let words=[...this.state.words]
            console.log(words);
            words.sort((first,second)=>{
                if(first.keyword<second.keyword){
                    return -1;
                }
                if(second.keyword<first.keyword){
                    return 1;
                }
                return 0;
            })

            console.log(words)
            // const words=[...this.state.words];
            // const keywords=[]
            
            // for(var i=0;i<words.length;i++){
            //     keywords.push(words[i].keyword);
            // }
            // const keywordsSorted=keywords.sort()
            // console.log(keywordsSorted);
            // this.setState({
            //     keywords:keywords
            // })
        })
    }
    handleSubmit(keyword){
        console.log(keyword);
        CommonService.searchList(keyword)
        .then((res)=>{
            this.setState({
                keyword:res.data.keyword.toUpperCase(),
                descr:res.data.descr,
                isOpen:true,
                link:"/keyword?keyword="+keyword
            })
            console.log(this.state.link)
            console.log(this.state.keyword+" "+this.state.descr);

        })
    }
    render() {
        return (
            <div className="container" id="add-page">
                <div class="sidenav2">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                   <a href="/home"><b>HOME</b></a>
                <a href="/search"><b>SEARCH</b></a>
                <a href="/view"><b>GLOSSARY</b></a>
                </div>
                <div className="row" >
                    <div class="card"  style={{width: "65rem",height:"33rem"}}>
                    <br></br>
                <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title"><b>GLOSSARY</b></h2>
                    <div id="logout"><a href="/login">Logout</a></div>
                    </div></div><br></br>
                <div id="view-table">
                    <br></br>
                   
                        {
                            this.state.words.map(word =>  {
                                    return <div>
                                  
                                    <td id="word"><Link to={{pathname:'/keyword',
                                        keywordProps:{
                                            word:word,
                                        }
                                    }}>{word.keyword}</Link></td>
                                    
                                    </div>
                                    
                                })
                                
                            }    
                    
                    </div>
                </div>
                </div>
            </div>
        );
    }
}

export default ViewAll;