import React, { Component } from 'react';
import AdminService from '../service/AdminService';
import CommonService from '../service/CommonService';
import { Modal,Button } from 'react-bootstrap';
import AliceCarousel from 'react-alice-carousel';
import "react-alice-carousel/lib/alice-carousel.css";
import toast from 'react-simple-toasts';

class Delete extends Component {
    constructor(props){
        super(props);
        this.state = {
            keyword:'',
            descr:'',
            isOpen:false,
            images:[],
            no_of_images:''
        }
    }
    openModal = () => 
    this.setState({ 
        isOpen: true 
    });
    closeModal = () =>{ 
        this.setState({ isOpen: false });

    }
    handleSubmitDelete(){
        var keyword = document.getElementById("keyword").value;
        AdminService.deleteWord(keyword);
        toast('Word deleted Successfully!')
    }
    handleSubmit(){
        var search = document.getElementById("keyword").value;
        if(search===""){
            toast('Please enter a word')
        }
        this.state.images=[]
        CommonService.searchList(search)
        .then((res)=>{
            this.setState({
                keyword:res.data.keyword,
                descr:res.data.descr,
                isOpen:true
            })
            console.log(this.state.keyword+" "+this.state.descr);
            if(res.data===""){
                this.setState({
                    isOpen:false
                })
                // document.getElementById("notfound").innerHTML="Sorry the word is not in the Dictionary"
                console.log("notfound");
                toast('Sorry, Word not found in the Dictionary.',1000)
            }
           
        })
        AdminService.getNumOfImag(search)
        .then((res)=>{
            this.setState({
                no_of_images:res.data
            })
            console.log(this.state.no_of_images);
            const images=[...this.state.images]
            
            for(var i=0;i<this.state.no_of_images;i++){
                images.push("http://localhost:8086/getImage/"+search+i)
            }
            this.setState({
                images:images
            })
            console.log(this.state.images);
        })
        
    }
    render() {
        return (
            <div className="container" id="add-page" >
                 <div class="sidenavadmin">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a href="/homeadmin"><b>HOME</b></a>
                <a href="/searchadmin"><b>SEARCH</b></a>
                <a href="/adminview"><b>GLOSSARY</b></a>
                <a href="/add"><b>ADD WORD</b></a>
                <a href="/delete"><b>DELETE</b></a>
                <a href="/users"><b>USER LIST</b></a>
                <a href="/update"><b>UPDATE</b></a>
                <a href="/addadmin"><b>ADD ADMIN</b></a>

                </div>
               <div className="row"  >
                 <div class="card" style={{width: "65rem",height:"33rem"}}>
                 <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title"><b>DELETE WORD</b></h2>
                    <div id="logout"><a href="/login">Logout</a></div>
                    </div></div>
                <div className="card-body">
                <br></br><br>
                </br>
                <div className="col-6" style={{paddingLeft:"200px"}}>
                <div class="col-16">
                    <input className="form-control" id="keyword" name="find_id" type="text"></input>
                <br></br>
                    <button  className="btn btn-primary" id="bt-search" onClick={this.handleSubmit.bind(this)}>SEARCH</button>
                    &emsp;
                    <button  className="btn btn-primary" id="bt-search" onClick={this.handleSubmitDelete.bind(this)}>DELETE</button>
                </div>
                </div>
                <br></br>
                

                    <div id="notfound"></div>
                    
      
                    <Modal centered show={this.state.isOpen} onHide={this.closeModal}>
                        <Modal.Header >
                            <div className="col-12">
                            <Modal.Title  >{this.state.keyword}</Modal.Title>
                            </div>
                        </Modal.Header>
                        <Modal.Body>
                            
                            {
                               this.state.descr
                               
                            }
                            <br></br><br></br>
                            <center>
                                <AliceCarousel autoPlay autoPlayInterval="3000" infinite="true" >
                                {
                                this.state.images.map(
                                    image => 
                                    <img src={image} className="sliderimg" alt={image}  />
                                )
                            }
                             </AliceCarousel>
                             </center>
                            

                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.closeModal}>
                            Close
                            </Button>
                        </Modal.Footer>
                        </Modal>
                    </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Delete;