import React, { Component } from 'react';
import RegService from '../service/RegService';

class Registration extends Component {
    constructor(props){
        super(props);
        this.state={
            name:'',
            username:'',
            password:'',
            confpass:''
        }
    }
    
    changeNameHandler=(event)=>{
        this.setState({name: event.target.value});
        console.log(event.target.value);
    }
    changeUserNameHandler=(event)=>{
        this.setState({username: event.target.value});
        console.log(event.target.value);
    }

    changePasswordHandler=(event)=>{
        this.setState({password:event.target.value});
        console.log(event.target.value);
    }
    changeConfPasswordHandler=(event)=>{
        this.setState({confpassword:event.target.value});
        console.log(event.target.value);
    }
    validation(username,password,name,confpassword){
        var counter=0;
        const isPasswordSecure = (password) => {
            const re = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
            return re.test(password);
        };
        // const isName = (name) => {
        //     const reg = new RegExp("/^[a-zA-Z]/");
        //     return reg.test(name);
        // }
        if (!isPasswordSecure(password)) {
            counter++;
            document.getElementById("error").innerHTML='Password must has at least 8 characters that include at least 1 lowercase character, 1 uppercase characters, 1 number, and 1 special character in (!@#$%^&*)';
        }
        if(name=="" || username=="" || password=="" || confpassword==""){
            counter++;
            document.getElementById("error").innerHTML="All fields are required!";
        }
        if(password!=confpassword){
            counter++;
            document.getElementById("error").innerHTML="Passwords don't match!"
        }
        if(counter==0){
            return true;
        }
        else{
            return false;
        }
    }
    handleSubmit(event){
        event.preventDefault();
        var regularExpUsername = "^[[A-Z]|[a-z]][[A-Z]|[a-z]|\\d|[_]]{7,29}$";
        var name= document.getElementById("name").value;
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;
        var confpassword = document.getElementById("confpassword").value;
        var flag=true;
        
        flag=this.validation(username,password,name,confpassword);
        console.log(flag);
        // if(!isName(name)){
        //     flag=0;
        //     document.getElementById("error").innerHTML="Name is not acceptable"
        // }
        if(flag==true)
        {
            
            const data ={
                name:name,
                username:username,
                password:password,
                confpassword:confpassword
            }
            RegService.register(data)
            .then((res)=>{
                if(res.data===""){
                    console.log("errror");
                }
                else{
                document.location.href="http://localhost:3000/home";
                }
            })
        }
    }

    render() {
        return (
            <div>
                <div className="container">
                
                <div className="row" id="reg-form">
                    <div className="card" id="card" style={{width:"25rem"}}><br></br>
                    <div class="card-header" style={{background:"white"}}>
                            <h2 class="card-title"><b>REGISTER</b></h2>
                            </div>
                            <div className="card-body">
                            <small class="card-subtitle mb-2 text-muted">Welcome to iWish Solutions!</small><br></br>
                            <br></br> 
                            <div><small style={{color:"red"}} id="error"></small></div>
                            <form>
                            <div className="card-text">
                                    <input type="text" placeholder="Name" required class="form-control" id="name" name="name" onChange={this.changeNameHandler} />
                                </div><br></br>
                                <div className="form-group">
                                    <input type="text" placeholder="Username" required className="form-control" id="username" name="username" onChange={this.changeUserNameHandler} />
                                </div><br></br>
                                <div className="form-group">
                                    <input type="password" placeholder="Password" required className="form-control" id="password" name="password" onChange={this.changePasswordHandler}></input>
                                </div><br></br>
                                <div className="form-group">
                                    <input type="password" placeholder="Confirm Password" required className="form-control" id="confpassword" name="confpassword" onChange={this.changeConfPasswordHandler}></input>
                                </div><br></br>
                               
                                <div >
                                <button onClick={this.handleSubmit.bind(this)} type="submit" id="bt" class="bt"><b>REGISTER</b></button>
                                <a href="/login" color="#2b7c68">Login here</a>
                                </div>
                                </form>
                                </div>
                                <br></br>
                        
                    </div>
                </div>
            </div>
            </div>
        );
    }
}

export default Registration;