import React, { Component } from 'react';
import toast from 'react-simple-toasts';
import RegService from '../service/RegService';

class AddAdmin extends Component {
    handleSubmit(){
        var name = document.getElementById("name").value;
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;
        var roles = "admin";
        const data ={
            name:name,
            username:username,
            password:password,
            confpassword:password,
            roles: roles         
        }
        RegService.register(data)
        .then(res => {
            if(res.data==="")
                toast('Sorry, Unable to add new Admin',1000)
            else{
                toast('Successfully Added')
            }
        })

    }
    render() {
        return (
            <div>
                <div className="container" id="add-page">
                <div class="sidenavadmin">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a href="/homeadmin"><b>HOME</b></a>
                <a href="/searchadmin"><b>SEARCH</b></a>
                <a href="/adminview"><b>GLOSSARY</b></a>
                <a href="/add"><b>ADD WORD</b></a>
                <a href="/delete"><b>DELETE</b></a>
                <a href="/users"><b>USER LIST</b></a>
                <a href="/update"><b>UPDATE</b></a>
                <a href="/addadmin"><b>ADD ADMIN</b></a>

                </div>
                <div className="row" >
                    <div class="card"  style={{width: "65rem",height:"33rem"}}>
                    <br></br>
                <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title"><b>&emsp;ADD ADMIN</b></h2>
                    <div id="logout"><a href="/login">Logout</a></div>
            </div></div><br></br>
                    
                    <small style={{color:"red"}} id="err"></small>
                <div id="view-table">
                    <br></br>
                                 <div className="col-7">
                                     <input placeholder="Name" type="text" className="form-control" id="name" name="name" onChange={this.changeNameHandler} />
                                 </div><br></br>
                                 <div className="col-7">
                                     <input type="text" placeholder="Username" className="form-control" id="username" name="username" onChange={this.changeDescriptionHandler}></input>
                                 </div><br></br>
                                 <div className="col-7">
                                     <input type="text" placeholder="Password" className="form-control" id="password" name="password" onChange={this.changeDescriptionHandler}></input>
                                 </div>
                                 <br></br>
                                 
                                <br></br>
                                <br></br>
                                <div className="col-6">
                                <button onClick={this.handleSubmit.bind(this)}  id="bt-search" style={{height:"40px"   }} className="btn btn-primary">ADD ADMIN</button>
                                </div>
                    
                    </div>
                </div>
                </div>
            </div>
            </div>
        );
    }
}

export default AddAdmin;