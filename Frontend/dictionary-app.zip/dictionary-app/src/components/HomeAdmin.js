import React, { Component } from 'react';

class HomeAdmin extends Component {
    render() {
        return (
            <div>
                <div className="container" id="add-page">
                <div class="sidenavadmin">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a href="/homeadmin"><b>HOME</b></a>
                <a href="/searchadmin"><b>SEARCH</b></a>
                <a href="/adminview"><b>GLOSSARY</b></a>
                <a href="/add"><b>ADD WORD</b></a>
                <a href="/delete"><b>DELETE</b></a>
                <a href="/users"><b>USER LIST</b></a>
                <a href="/update"><b>UPDATE</b></a>
                <a href="/addadmin"><b>ADD ADMIN</b></a>

                </div>
                <div >
                    <div class="card"  style={{width: "65rem",height:"33rem"}}>
                    <br></br>
                <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title" style={{fontFamily:"fantasy"}}><b>&emsp;iWish Softwares</b></h2>
                    <div id="logout"><a href="/login">Logout</a></div>
                    </div></div>
                    <br></br>
                    <small style={{color:"red"}} id="err"></small>
                <div>
                <div style={{fontFamily:"cursive"}}>
                  Welcome to iWish Software...<br></br>
               <div> i<b>Wish</b> wish you a happy Learning Experience! </div>  
                </div><br></br><br></br>
               <div className="card-body" id="homepage" style={{paddingLeft:"100px",fontFamily:"sans-serif"}}>
                      <b>  AGENDAS FOR THE YEAR 2021-22</b><br></br><br></br>
                        <small>
                            1. Faster search results<br></br>&emsp;&emsp;&emsp;
                            2. Customer friendly glossary<br></br>&emsp;&emsp;&emsp;
                            3. Hardwork gives off success<br></br>
                        </small>
                        
                             </div>
                </div><br></br>

                              
                    
                    </div>
                </div>
                </div>
        
            </div>
        );
    }
}

export default HomeAdmin;