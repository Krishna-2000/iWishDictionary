import React from "react";
import Image from "./Image"

const ImageContainer= (props) =>{
    
    const display=()=>{
        // return props.images.map(image =>{
             return <Image url={props.images.url}></Image>;
        // });
        
    }

    return(
        <div>
            {display()}
        </div>
    )
}

export default ImageContainer;