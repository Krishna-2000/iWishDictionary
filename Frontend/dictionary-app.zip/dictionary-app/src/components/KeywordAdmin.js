import React, { Component } from 'react';
import CommonService from '../service/CommonService';
import AdminService from '../service/AdminService';
import AliceCarousel from 'react-alice-carousel';
import "react-alice-carousel/lib/alice-carousel.css";
const KeywordAdmin = (props) => {
    
    const word = props.location.keywordProps;
    console.log(word);
    console.log(word.word.keyword);
    console.log(word.word.img)
    var images=[];
    for(var i=0;i<word.word.img;i++){
        images.push("http://localhost:8086/getImage/"+word.word.keyword+i);
    }
    console.log(images)
    return (
        <div className="container">
                <div class="sidenavadmin">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a href="/homeadmin"><b>HOME</b></a>
                <a href="/searchadmin"><b>SEARCH</b></a>
                <a href="/adminview"><b>GLOSSARY</b></a>
                <a href="/add"><b>ADD WORD</b></a>
                <a href="/delete"><b>DELETE</b></a>
                <a href="/users"><b>USER LIST</b></a>
                <a href="/update"><b>UPDATE</b></a>
                <a href="/addadmin"><b>ADD ADMIN</b></a>

                </div>
               <div className="row" id="search-page" >
                <div class="card"  style={{width: "65rem",height:"33rem"}}>
                <br></br>
                <div class="card-header" style={{background:"white"}}>

                    <div><h2 class="card-title"><b>{word.word.keyword}</b></h2>
                    <div id="logout"><a href="/login">Logout</a></div>
                    </div></div><br></br>
                
                <div className="card-body"  >
                    <div id="des">
                    {word.word.descr}</div>
                <br></br>
                <br></br>
                <br></br>
                <AliceCarousel autoPlay autoPlayInterval="3000" infinite="true" disableDotsControls="true" >
                                {
                                images.map(
                                    image => 
                                    <img src={image} className="sliderimg" alt={image}  style={{width:"330px",height:"180px"}} />
                                )
                            }
                             </AliceCarousel>
                    </div>
                    </div>
                    </div>
                    
                    

            </div>
    )
}

export default KeywordAdmin;