import React, { Component } from 'react';
import CommonService from '../service/CommonService';
import { Modal,Button } from 'react-bootstrap';
import AdminService from '../service/AdminService';
import axios from 'axios';

class Find extends Component {

    constructor(props){
        super(props);

        this.state={
            keyword:'',
            descr:'',
            isOpen:false,
            images:[],
            no_of_images:''
        }

    }
    openModal = () => 
    this.setState({ 
        isOpen: true 
    });
    closeModal = () =>{ 
        this.setState({ isOpen: false });

    }

    handleSubmit=()=>{
        
        var search = document.getElementById("keyword").value;
      
        CommonService.searchList(search)
        .then((res)=>{
            this.setState({
                keyword:res.data.keyword.toUpperCase(),
                descr:res.data.descr,
                isOpen:true
            })
            console.log(this.state.keyword+" "+this.state.descr);
            if(res.data===""){
                this.setState({
                    isOpen:false
                })
                document.getElementById("notfound").innerHTML="Sorry the word is not in the Dictionary"
                console.log("notfound");
            }
        })
        AdminService.getNumOfImag(search)
        .then((res)=>{
            this.setState({
                no_of_images:res.data
            })
            console.log(this.state.no_of_images);
            for(var i=0;i<this.state.no_of_images;i++){
                fetch("http://localhost:8086/getImage/"+this.state.keyword+i,{
                    method:'get',
                    
                })
                .then(res => {
                    console.log('res',res);
                    if(!res.ok){
                        throw Error("Error !");
                    }
                    this.setState({
                        images:res
                    })
                });
            
            }
        })
        

    }
    onKeyChangeHandler = (event)=>{
        this.setState({keyword:this.state.keyword.toUpperCase()})
    }
    render() {
        return (
            <div className="container">
                <div class="sidenav">
                <a href="#about">About</a>
                <a href="#services">Services</a>
                <a href="#clients">Clients</a>
                <a href="#contact">Contact</a>
                </div>
               <div className="row" id="search-page" >
                <div class="card"  style={{width: "65rem",height:"33rem"}}>
                <br></br>
                <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title"><b>SEARCH WORD</b></h2></div></div><br></br>
                <div className="card-body">
                <div className="col-7" style={{paddingLeft:"200px"}}>
                    <div class="input-group mb-3">
                    <input className="form-control"  id="keyword" name="keyword" type="text" onChange={this.onKeyChange}></input>
                    <div class="input-group-append">
                    <button className="btn btn-primary" id="bt-search" onClick={this.handleSubmit.bind(this)}>SEARCH</button>
                    </div>
                    </div>
                </div>
                <br></br>
                <table className="table table-stripped table-bordered">
                      
                    </table>
                    <div id="notfound"></div>
                     
      
                    <Modal centered show={this.state.isOpen} onHide={this.closeModal}>
                        <Modal.Header >
                            <div className="col-12">
                            <Modal.Title  >{this.state.keyword}</Modal.Title>
                            </div>
                        </Modal.Header>
                        <Modal.Body>
                            {
                               this.state.descr
                            }
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.closeModal}>
                            Close
                            </Button>
                        </Modal.Footer>
                        </Modal>


                            {/* <ImageContainer images={this.state.images}></ImageContainer> */}

                    </div>
                    </div>
                    </div>
                    
                    

            </div>
        );
    }
}

export default Find;