import React, { Component } from 'react';
import AdminService from '../service/AdminService';

class GetUsers extends Component {
    constructor(props){
        super(props);
        this.state={
            user:[]
        }
    }
    componentDidMount(){
        AdminService.getUsers()
        .then(res => {
            console.log(res.data)
            this.setState({
                user:res.data
            })
        })
    }
    render() {
        return (
            <div className="container" id="view-page">
             <div class="sidenavadmin">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a href="/homeadmin"><b>HOME</b></a>
                <a href="/searchadmin"><b>SEARCH</b></a>
                <a href="/adminview"><b>GLOSSARY</b></a>
                <a href="/add"><b>ADD WORD</b></a>
                <a href="/delete"><b>DELETE</b></a>
                <a href="/users"><b>USER LIST</b></a>
                <a href="/update"><b>UPDATE</b></a>
                <a href="/addadmin"><b>ADD ADMIN</b></a>

                </div>
            <div className="row" >
                <div class="card"  style={{width: "65rem",height:"33rem"}}>
                <br></br>
            <div class="card-header" style={{background:"white"}}>
                <div><h2 class="card-title"><b>&emsp;LIST OF USERS</b></h2>
                <div id="logout"><a href="/login">Logout</a></div>
                </div></div><br></br>
                <small style={{color:"red"}} id="err"></small>
            <div id="view-table">
                <br></br>
                <div className="card-body">
                <table className="table table-stripped table-bordered">
                        <thead>
                        <tr>
                            <th>USER'S NAME</th>
                            <th>USERNAME</th>
                            
                        </tr>
                        </thead>
                        <tbody>
                        {
                            this.state.user.map(
                                each => 
                                <tr>
                                    <td>{each.name}</td>
                                    <td>{each.username}</td>
                                </tr>
                            )

                        }
                        
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
        );
    }
}

export default GetUsers;