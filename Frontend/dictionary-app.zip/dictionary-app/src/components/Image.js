import React from "react";

const Image = (props) => {
    console.log(props);
    return (
        <div>
            <img src={"data:image/png:base64,"+props.url} alt="images"></img>
        </div>
    )
}
export default Image;