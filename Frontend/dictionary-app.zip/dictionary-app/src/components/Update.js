import React, { Component } from 'react';
import AdminService from '../service/AdminService';
import axios from 'axios';
import CommonService from '../service/CommonService';
import toast from 'react-simple-toasts';

class AddWord extends Component {
    constructor(props){
        super(props);
        this.state={
            id:'',
            keyword:'',
            descr:'',
            files:[],
            n:''
        }
    }
    changeIdHandler=(event)=>{
        this.setState({id: event.target.value})
    }
    changeKeywordHandler=(event)=>{
        this.setState({keyword: event.target.value})
    }

    changeDescriptionHandler=(event)=>{
        this.setState({descr:event.target.value})
    }
    onFileChangeHandler = (e) => {
        var keyword = document.getElementById("keyword").value;
        if(keyword===""){
            // document.getElementById("err").innerHTML="Please enter a keyword";
            toast('Please enter a word')
        }
        else{
            document.getElementById("err").innerHTML="";
            const formData = new FormData();
            if(e.target.files.length>=6){
                // document.getElementById("err").innerHTML="You can only select a maximum of 6 files";
                toast('Sorry, You cant select more than 6 images for one keyword')
            }else{
            for(var i = 0; i< e.target.files.length; i++) {
                formData.append('file', e.target.files[i],keyword+i);
                console.log(e.target.files[i]);
            }
            this.setState({
                n:e.target.files.length
            })
            const config={
                headers:{
                    'content-type':'multipart/form-data'
                }
            }
            axios.post("http://localhost:8086/upload", formData,config)
            .then(res => { // then print response status
                console.log(res.statusText)
                toast('Word updated Successfully!')
            })
    }}
    };
    fetcher(){
        var keyword = document.getElementById("keyword").value;
        if(keyword===""){
            toast('Please enter a keyword')
        }
        CommonService.searchList(keyword)
        .then(res=>{
            this.setState({
                n:res.data.img,
                descr:res.data.descr
            })
            console.log(res);
            if(res.data===""){
                // document.getElementById("err").innerHTML="Keyword not found!";
                toast('Sorry the word is not in the Dictionary',1000)
            }
            else{
            console.log(this.state.n)
            document.getElementById("err").innerHTML="";
            document.getElementById("descr").value=this.state.descr
            }
        })
        console.log(this.state.n);
    }
    handleSubmit(e){
        var keyword = document.getElementById("keyword").value;
        var descr = document.getElementById("descr").value;
        if(keyword==="" || descr==="")
            toast('Please fill the fields')
        const data={
            keyword:keyword,
            descr:descr,
            img:this.state.n
        }
        console.log(data);
        AdminService.updateWord(data)
        .then((res)=>{
            
                toast('Word updates Successfully!');
                e.preventDefault();
            
        })
    }
    render() {
        return (
            <div className="container" id="add-page">
                <div class="sidenavadmin">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a href="/homeadmin"><b>HOME</b></a>
                <a href="/searchadmin"><b>SEARCH</b></a>
                <a href="/adminview"><b>GLOSSARY</b></a>
                <a href="/add"><b>ADD WORD</b></a>
                <a href="/delete"><b>DELETE</b></a>
                <a href="/users"><b>USER LIST</b></a>
                <a href="/update"><b>UPDATE</b></a>
                <a href="/addadmin"><b>ADD ADMIN</b></a>

                </div>
                <div className="row" >
                    <div class="card"  style={{width: "65rem",height:"33rem"}}>
                    <br></br>
                <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title"><b>&emsp;UPDATE WORD</b></h2>
                    <div id="logout"><a href="/login">Logout</a></div>
                    </div></div><br></br>
                    <small style={{color:"red"}} id="err"></small>
                <div id="view-table">
                    <br></br>
                                
                                 <div className="col-9">
                                 <div class="input-group mb-3">
                                 <input placeholder="Keyword" type="text" className="form-control" id="keyword" name="keyword" onChange={this.changeKeywordHandler} />
                                <div class="input-group-append">
                                <button className="btn btn-primary" id="bt-search" onClick={this.fetcher.bind(this)}>FETCH</button>
                                </div>
                                </div>
                                 </div><br></br>
                                 <div className="col-7">
                                     <input type="text" placeholder="Description" className="form-control" id="descr" name="descr" onChange={this.changeDescriptionHandler}></input>
                                 </div>
                                 <br></br>
                                 {/* <div className="col-7">
                                 <input type="file" className="form-control" name="file" multiple
                                 onChange={this.onFileChangeHandler}/>
                                </div> */}
                                <br></br>
                                <br></br>
                                <div className="col-6">
                                <button onClick={this.handleSubmit.bind(this)}  id="bt-search" style={{height:"40px"   }} className="btn btn-primary">UPDATE WORD</button>
                                </div>
                    
                    </div>
                </div>
                </div>
            </div>
           
        );
    }
}

export default AddWord;