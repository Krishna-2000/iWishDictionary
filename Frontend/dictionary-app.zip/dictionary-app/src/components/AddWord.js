import React, { Component } from 'react';
import AdminService from '../service/AdminService';
import axios from 'axios';
import toast from 'react-simple-toasts';


class AddWord extends Component {
    constructor(props){
        super(props);
        this.state={
            id:'',
            keyword:'',
            descr:'',
            files:[],
            n:''
        }
    }
    changeIdHandler=(event)=>{
        this.setState({id: event.target.value})
    }
    changeKeywordHandler=(event)=>{
        this.setState({keyword: event.target.value})
    }

    changeDescriptionHandler=(event)=>{
        this.setState({descr:event.target.value})
    }
    onFileChangeHandler = (e) => {
        var keyword = document.getElementById("keyword").value;
        
            document.getElementById("err").innerHTML="";
            const formData = new FormData();
            if(e.target.files.length>=6){
                toast('You can only select a maximum of 6 files');
            }else{
                console.log(e.target.files.length)
            for(var i = 0; i< e.target.files.length; i++) {
                formData.append('file', e.target.files[i],keyword+i);
                console.log(e.target.files[i]);
            }
            this.setState({
                n:e.target.files.length
            })
            const config={
                headers:{
                    'content-type':'multipart/form-data'
                }
            }
            axios.post("http://localhost:8086/upload", formData,config)
            .then(res => { // then print response status
                console.log(res.statusText)
            })
    }
    };
    handleSubmit(e){
        var keyword = document.getElementById("keyword").value;
        console.log(keyword)
        var descr = document.getElementById("descr").value;
        var num = this.state.n;
        if((keyword==="") || (descr==="")){
            toast('Please fill the fields',1500);
        }
        else{
        const data={
            keyword:keyword,
            descr:descr,
            img:num
        }
        AdminService.addWord(data)
        .then((res)=>{
            if(res.data===""){
                console.log("errror");
            }
            else{
                toast('Word added Successfully!',1000)
                e.preventDefault();
            }
        })
    }
    }
    render() {
        return (
            <div className="container" id="add-page">
                <div class="sidenavadmin">
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a></a>
                  <a href="/homeadmin"><b>HOME</b></a>
                <a href="/searchadmin"><b>SEARCH</b></a>
                <a href="/adminview"><b>GLOSSARY</b></a>
                <a href="/add"><b>ADD WORD</b></a>
                <a href="/delete"><b>DELETE</b></a>
                <a href="/users"><b>USER LIST</b></a>
                <a href="/update"><b>UPDATE</b></a>
                <a href="/addadmin"><b>ADD ADMIN</b></a>

                </div>
                <div className="row" >
                    <div class="card"  style={{width: "65rem",height:"33rem"}}>
                    <br></br>
                <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title"><b>&emsp;ADD NEW WORD</b></h2>
                    <div id="logout"><a href="/login">Logout</a></div>
            </div></div><br></br>
                    
                    <small style={{color:"red"}} id="err"></small>
                <div id="view-table">
                    <br></br>
                                 <div className="col-7">
                                     <input placeholder="Keyword" type="text" className="form-control" id="keyword" name="keyword" onChange={this.changeKeywordHandler} />
                                 </div><br></br>
                                 <div className="col-7">
                                     <input type="text" placeholder="Description" className="form-control" id="descr" name="descr" onChange={this.changeDescriptionHandler}></input>
                                 </div>
                                 <br></br>
                                 <div className="col-7">
                                 <input type="file" className="form-control" name="file" multiple
                                 onChange={this.onFileChangeHandler}/>
                                </div>
                                <br></br>
                                <br></br>
                                <div className="col-6">
                                <button onClick={this.handleSubmit.bind(this)}  id="bt-search" style={{height:"40px"   }} className="btn btn-primary">ADD WORD</button>
                                </div>
                    
                    </div>
                </div>
                </div>
            </div>
           
        );
    }
}

export default AddWord;