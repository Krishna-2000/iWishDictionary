import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import LoginService from '../service/LoginService';

class Login extends Component {
    constructor(props){
        super(props);
        this.state={
            username:'',
            password:''
        }
    }
    

    changeUserNameHandler=(event)=>{
        this.setState({username: event.target.value})
    }

    changePasswordHandler=(event)=>{
        this.setState({password:event.target.value})
    }
    

    handleSubmit(event) {
        event.preventDefault();

        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;
        
        LoginService.loginValidate(username,password)
        .then((res)=>{
            if(res.data===""){
                console.log("invalid username/password");
                document.getElementById("error").innerHTML="Invalid Username/Password"
            }
            else if(res.data.roles==="admin"){
                document.location.href="http://localhost:3000/homeadmin";
            }
            else{
                document.location.href="http://localhost:3000/home";
            }
        })
    }
    render() {
        return (
            <div className="container">
                
                <div className="row" id="login-form">
                    <div className="card" id="card" style={{width:"25rem"}}><br></br>
                    <div class="card-header" style={{background:"white"}}>
                    <div><h2 class="card-title"><b>LOGIN</b></h2>
                    </div></div>
                    <div className="card-body">
                            <small class="card-subtitle mb-2 text-muted">Welcome to iWish Solutions!</small><br></br>
                            <br></br> 
                            <small id="error" style={{color:"red"}}></small>
                            <form>
                                <div className="form-group">
                                    <input type="text" placeholder="Username" className="form-control" id="username" name="username" onChange={this.changeUserNameHandler} />
                                </div><br></br>
                                <div className="form-group">
                                    <input type="password" placeholder="Password" className="form-control" id="password" name="password" onChange={this.changePasswordHandler}></input>
                                </div>
                                <br></br>
                                <div >
                                <button onClick={this.handleSubmit.bind(this)} type="submit" id="bt" className="btn btn-primary">LOGIN</button>
                                <a href="/reg" color="#2b7c68">Register here</a>
                                </div>
                                </form>
                                <br></br>
                       </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Login;